#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

//MENUS
menuEquipe() {
  int op = 0;
  while (op != 6) {
    printf("!\n");
    if (obterTotalEquipe() < 20) {
      printf("1 - Inserir Equipe\n");
    }
    printf("2 - Alterar Equipe\n");
    if (obterTotalEquipe() > 0) {
      printf("3 - Apagar\n");
    }
    printf("4 - Listar Equipes\n");
    printf("5 - Pesquisar Equipes\n");
    printf("6 - Voltar\n");
    printf("Informe a opcao desejada: \n");
    scanf("%d", & op);

    Opcao(op);
  }
}

//COLETANDO A OP��O ESCOLHIDA
Opcao(int opcaoSelecionada) {

  //CASO A OP��O 1 FOR ESCOLHIDA, INSERE UMA EQUIPE
  if (opcaoSelecionada == 1) {
    inserirEquipe();

    //CASO A OP��O 2 FOR ESCOLHIDA, ALTERA UMA EQUIPE
  } else if (opcaoSelecionada == 2) {
    listarEquipe();
    atualizarEquipe();

    //CASO A OP��O 3 FOR ESCOLHIDA, DELETA UMA QUIPE
  } else if (opcaoSelecionada == 3) {
    listarEquipe();
    deleteEquipe();

    //CASO A OP��O 4 FOR ESCOLHIDA, LISTA AS EQUIPES
  } else if (opcaoSelecionada == 4) {
    listarEquipe();

    //CASO A OP��O 5 FOR ESCOLHIDA, PESQUISA UMA EQUIPE
  } else if (opcaoSelecionada == 5) {
    pesquisarEquipe();
  }
}

#endif
