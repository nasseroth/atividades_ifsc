#ifndef RESULTADOS_H_INCLUDED
#define RESULTADOS_H_INCLUDED


Resultado();


#endif
